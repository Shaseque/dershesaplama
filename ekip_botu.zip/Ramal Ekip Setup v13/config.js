﻿const config = {
  "botStatus": [""],
  "prefix": ["!", "."],
  "token": "",
  "mongoose": "",
  "botOwners": ["962417173043753022"],
  "guildID": "1020455351474212954",
  
  "emojis": {
    "yes_name": "yes_ramal",
    "no_name": "no_ramal",
    "mute_name": "ramal_mute"
  }
  }
  
  module.exports = config;
  